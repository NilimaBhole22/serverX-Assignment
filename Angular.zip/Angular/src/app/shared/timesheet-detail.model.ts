export class TimesheetDetail {
    id :number;
    user :string;
    projectName :string;
    hour :number;
    comment :string;
}
