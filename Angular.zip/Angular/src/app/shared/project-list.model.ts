export class ProjectList {
    id :number;
    project :string;
}
