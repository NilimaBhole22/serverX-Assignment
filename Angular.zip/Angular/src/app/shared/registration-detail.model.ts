export class RegistrationDetail {
    id :number;
    username :string;
    password :string;
    confirmPassword :string;
    userId :string;
}
