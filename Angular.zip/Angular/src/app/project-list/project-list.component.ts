import { Component, OnInit } from '@angular/core';
import { ProjectListService } from 'app/shared/project-list.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-project-list',
  templateUrl: './project-list.component.html',
  styles: []
})
export class ProjectListComponent implements OnInit {
  constructor() { }

  ngOnInit(){
    
  }

}
